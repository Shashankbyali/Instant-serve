importScripts('https://www.gstatic.com/firebasejs/9.6.1/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/9.6.1/firebase-messaging-compat.js');

firebase.initializeApp({
    apiKey: "AIzaSyA8kPTzhkZZfOC6eiPoo19Ph8g4s3RmguU",
    authDomain: "instant-serve-xxxxx.firebaseapp.com",
    projectId: "instant-serve-xxxxx",
    storageBucket: "instant-serve-xxxxx.appspot.com",
    messagingSenderId: "YOUR_SENDER_ID",
    appId: "YOUR_APP_ID"
});

const messaging = firebase.messaging();

// Handle background messages
messaging.onBackgroundMessage((payload) => {
    console.log('Received background message:', payload);

    const notificationTitle = payload.notification.title;
    const notificationOptions = {
        body: payload.notification.body,
        icon: '/static/logo.png'
    };

    self.registration.showNotification(notificationTitle, notificationOptions);
}); 