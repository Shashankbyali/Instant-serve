from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_qrcode import QRcode
import sqlite3
import os
from pyfcm import FCMNotification
from datetime import datetime
from twilio.rest import Client
import ast

app = Flask(__name__)
app.secret_key = '5ea1630e32bbc39faab4a5d5b65beb753d3e3ed0c3b239240a28ca54b366badd'
QRcode(app)

# Firebase Cloud Messaging setup
firebase_api_key = "AIzaSyA8kPTzhkZZfOC6eiPoo19Ph8g4s3RmguU"
push_service = FCMNotification(api_key=firebase_api_key)


# Database initialization
def init_db():
    conn = sqlite3.connect('instant_serve.db')
    c = conn.cursor()
    
    # Create tables
    c.execute('''CREATE TABLE IF NOT EXISTS owners
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 username TEXT UNIQUE,
                 password TEXT,
                 canteen_name TEXT)''')
    
    c.execute('''CREATE TABLE IF NOT EXISTS orders
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 owner_id INTEGER,
                 items TEXT,
                 total_price REAL,
                 status TEXT DEFAULT 'pending',
                 timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                 customer_name TEXT,
                 customer_phone TEXT,
                 fcm_token TEXT,
                 FOREIGN KEY(owner_id) REFERENCES owners(id))''')
    
    c.execute('''CREATE TABLE IF NOT EXISTS menu_items
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 owner_id INTEGER,
                 name TEXT,
                 description TEXT,
                 price REAL,
                 FOREIGN KEY(owner_id) REFERENCES owners(id))''')
    
    conn.commit()
    conn.close()

init_db()

# Helper functions
def get_db_connection():
    conn = sqlite3.connect('instant_serve.db')
    conn.row_factory = sqlite3.Row
    return conn

# Routes
@app.route('/')
def home():
    return render_template('home.html')

# Owner routes
@app.route('/owner/login', methods=['GET', 'POST'])
def owner_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db_connection()
        owner = conn.execute('SELECT * FROM owners WHERE username = ? AND password = ?', 
                            (username, password)).fetchone()
        conn.close()
        
        if owner:
            session['owner_id'] = owner['id']
            session['owner_name'] = owner['canteen_name']
            return redirect(url_for('owner_dashboard'))
        else:
            flash('Invalid username or password')
    
    return render_template('owner_login.html')

@app.route('/owner/signup', methods=['GET', 'POST'])
def owner_signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        canteen_name = request.form['canteen_name']
        
        if not username or not password or not canteen_name:
            flash('All fields are required')
            return render_template('owner_signup.html')
        
        conn = get_db_connection()
        
        # Check if username already exists
        existing_owner = conn.execute('SELECT * FROM owners WHERE username = ?', (username,)).fetchone()
        if existing_owner:
            flash('Username already exists')
            conn.close()
            return render_template('owner_signup.html')
        
        try:
            # Create new owner
            conn.execute('INSERT INTO owners (username, password, canteen_name) VALUES (?, ?, ?)',
                        (username, password, canteen_name))
            conn.commit()
            
            # Get the new owner's ID
            owner = conn.execute('SELECT * FROM owners WHERE username = ?', (username,)).fetchone()
            conn.close()
            
            session['owner_id'] = owner['id']
            session['owner_name'] = owner['canteen_name']
            flash('Account created successfully!')
            return redirect(url_for('owner_dashboard'))
        except Exception as e:
            conn.close()
            flash('An error occurred during signup. Please try again.')
            return render_template('owner_signup.html')
    
    return render_template('owner_signup.html')

@app.route('/owner/dashboard')
def owner_dashboard():
    if 'owner_id' not in session:
        return redirect(url_for('owner_login'))
    
    conn = get_db_connection()
    menu_items = conn.execute('SELECT * FROM menu_items WHERE owner_id = ?', 
                            (session['owner_id'],)).fetchall()
    orders = conn.execute('SELECT * FROM orders WHERE owner_id = ? ORDER BY timestamp DESC', 
                          (session['owner_id'],)).fetchall()
    conn.close()
    
    # Parse order items for each order
    orders_with_items = []
    for order in orders:
        order_dict = dict(order)
        try:
            order_dict['order_items'] = ast.literal_eval(order_dict['items'])
        except Exception:
            order_dict['order_items'] = []
        orders_with_items.append(order_dict)
    
    return render_template('owner_dashboard.html', menu_items=menu_items, orders=orders_with_items)

@app.route('/owner/add_item', methods=['POST'])
def add_menu_item():
    if 'owner_id' not in session:
        return redirect(url_for('owner_login'))
    
    name = request.form['name']
    description = request.form['description']
    price = float(request.form['price'])
    
    conn = get_db_connection()
    conn.execute('INSERT INTO menu_items (owner_id, name, description, price) VALUES (?, ?, ?, ?)',
                (session['owner_id'], name, description, price))
    conn.commit()
    conn.close()
    
    flash('Menu item added successfully')
    return redirect(url_for('owner_dashboard'))

@app.route('/verify_fcm_token', methods=['POST'])
def verify_fcm_token():
    try:
        data = request.get_json()
        token = data.get('token')
        if not token:
            return jsonify({'error': 'No token provided'}), 400
            
        # Test the token by sending a test notification
        test_result = send_fcm_notification(
            token,
            "Test Notification",
            "This is a test notification to verify your device is properly set up."
        )
        
        if test_result:
            return jsonify({'status': 'success', 'message': 'Token verified successfully'})
        else:
            return jsonify({'status': 'error', 'message': 'Failed to send test notification'}), 400
            
    except Exception as e:
        print('Token verification error:', e)
        return jsonify({'status': 'error', 'message': str(e)}), 500

def send_fcm_notification(fcm_token, title, body):
    try:
        # First, verify the token is not empty
        if not fcm_token or fcm_token.strip() == '':
            print('Empty FCM token provided')
            return False
            
        print(f'Sending notification to token: {fcm_token[:10]}...')
        
        message = {
            "notification": {
                "title": title,
                "body": body
            },
            "webpush": {
                "headers": {
                    "Urgency": "high"
                },
                "notification": {
                    "icon": "/static/logo.png",
                    "badge": "/static/badge.png",
                    "vibrate": [100, 50, 100],
                    "requireInteraction": True,
                    "actions": [
                        {
                            "action": "open",
                            "title": "View Order"
                        }
                    ]
                },
                "fcm_options": {
                    "link": "/orders"  # URL to open when notification is clicked
                }
            },
            "data": {
                "click_action": "/orders",
                "order_id": "test"  # Add actual order ID when sending real notifications
            }
        }
        
        # Send the notification
        result = push_service.notify_single_device(
            registration_id=fcm_token,
            message_title=title,
            message_body=body,
            data_message=message,
            sound="default"
        )
        
        print('FCM notification result:', result)
        
        # Check if the notification was sent successfully
        if result and 'success' in str(result).lower():
            print('Notification sent successfully')
            return True
        else:
            print('Failed to send notification:', result)
            return False
            
    except Exception as e:
        print('FCM notification error:', str(e))
        return False

@app.route('/owner/update_order_status/<int:order_id>', methods=['POST'])
def update_order_status(order_id):
    if 'owner_id' not in session:
        return redirect(url_for('owner_login'))
    
    new_status = request.form['status']
    
    conn = get_db_connection()
    # Get order details
    order = conn.execute('SELECT * FROM orders WHERE id = ?', (order_id,)).fetchone()
    # Update order status
    conn.execute('UPDATE orders SET status = ? WHERE id = ?', (new_status, order_id))
    conn.commit()
    conn.close()
    
    # Send notification to customer if status is 'ready'
    if new_status == 'ready':
        # Send SMS using Twilio
        try:
            twilio_sid = os.environ.get('TWILIO_ACCOUNT_SID', 'YOUR_TWILIO_SID')
            twilio_token = os.environ.get('TWILIO_AUTH_TOKEN', 'YOUR_TWILIO_AUTH_TOKEN')
            twilio_from = os.environ.get('TWILIO_FROM_NUMBER', 'YOUR_TWILIO_PHONE')
            client = Client(twilio_sid, twilio_token)
            sms_body = f"Hi {order['customer_name']}, your order #{order_id} is ready for pickup!"
            if order['customer_phone']:
                message = client.messages.create(
                    body=sms_body,
                    from_=twilio_from,
                    to=order['customer_phone']
                )
                print('Twilio message SID:', message.sid)
        except Exception as e:
            print('Twilio SMS error:', e)
            
        # Send FCM push notification
        if order['fcm_token']:
            notification_title = f"Order #{order_id} Ready"
            notification_body = f"Hi {order['customer_name']}, your order is ready for pickup!"
            notification_sent = send_fcm_notification(
                order['fcm_token'],
                notification_title,
                notification_body
            )
            if not notification_sent:
                print(f'Failed to send FCM notification for order {order_id}')
    
    flash('Order status updated')
    return redirect(url_for('owner_dashboard'))

# Remove customer login/signup routes and keep only owner routes
@app.route('/menu/<int:owner_id>')
def view_menu(owner_id):
    conn = get_db_connection()
    owner = conn.execute('SELECT * FROM owners WHERE id = ?', (owner_id,)).fetchone()
    menu_items = conn.execute('SELECT * FROM menu_items WHERE owner_id = ?', (owner_id,)).fetchall()
    conn.close()
    
    if not owner:
        flash('Canteen not found')
        return redirect(url_for('home'))
    
    # Convert menu_items to list of dicts for JSON serialization
    menu_items_dicts = [dict(item) for item in menu_items]

    return render_template('menu.html', owner=owner, menu_items=menu_items_dicts)

@app.route('/place_order', methods=['POST'])
def place_order():
    owner_id = request.form['owner_id']
    items = request.form.getlist('item')
    quantities = request.form.getlist('quantity')
    customer_name = request.form['customer_name']
    customer_phone = request.form['customer_phone']
    fcm_token = request.form.get('fcm_token', '')
    
    # Process order items
    order_items = []
    total_price = 0.0
    
    conn = get_db_connection()
    
    for item_id, quantity in zip(items, quantities):
        quantity = int(quantity)
        if quantity > 0:
            menu_item = conn.execute('SELECT * FROM menu_items WHERE id = ?', (item_id,)).fetchone()
            if menu_item:
                order_items.append({
                    'id': menu_item['id'],
                    'name': menu_item['name'],
                    'price': menu_item['price'],
                    'quantity': quantity
                })
                total_price += menu_item['price'] * quantity
    
    if not order_items:
        flash('No items selected')
        return redirect(url_for('view_menu', owner_id=owner_id))
    
    # Save order to database
    conn.execute('''INSERT INTO orders (owner_id, items, total_price, status, customer_name, customer_phone, fcm_token)
                   VALUES (?, ?, ?, 'pending', ?, ?, ?)''',
                (owner_id, str(order_items), total_price, customer_name, customer_phone, fcm_token))
    conn.commit()
    conn.close()
    
    flash('Order placed successfully!')
    return redirect(url_for('order_confirmation'))

@app.route('/order_confirmation')
def order_confirmation():
    return render_template('order_confirmation.html')

# QR Code route
@app.route('/qr/<int:owner_id>')
def generate_qr(owner_id):
    if 'owner_id' not in session or session['owner_id'] != owner_id:
        return "Unauthorized", 403
    
    qr_url = url_for('view_menu', owner_id=owner_id, _external=True)
    return render_template('qr_display.html', qr_url=qr_url)

@app.route('/debug')
def debug():
    return "Working!"  # If this shows, routing works
@app.route('/test_template')
def test_template():
    return render_template('customer_menu.html')  # Verify one template works

@app.route('/owner/logout')
def owner_logout():
    session.pop('owner_id', None)
    session.pop('owner_name', None)
    flash('Logged out successfully.')
    return redirect(url_for('owner_login'))

if __name__ == '__main__':
    app.run(debug=True)